#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

typedef struct {
	char nome[50];
	int idade;
	} Pessoa;
	
int main(){
	setlocale (LC_ALL, "Portuguese");
	
	Pessoa people;
	
	//solicita��o dos valores
	printf("Qual o nome da pessoa: ");
	scanf ("%s", &people.nome);
	
	printf("Qual a idade da pessoa: ");
	scanf ("%d", &people.idade);
	
	
	//aloca��o dos vetores com malloc
	people = malloc (sizeof(struct Pessoa));
	
	//la�o de repeti��o 
	for(int i=0; i<people; i++){
	printf("Digite a quantidade desejada: ");
	scanf ("%d", &vet[i]);
	
	}
	
	//la�o de repeti��o para mostrar os valores e calcular
	//for(int i=0; i<quant; i++){
	//printf("Valor digitado: %d\n", vet[i]);
	
	//soma = soma + vet[i];
	

	}
	
	//mostrar os valores calculados e liberar memoria
	//printf("Valor da soma: %d\n", soma);
	free(vet);
	return 0;
}

